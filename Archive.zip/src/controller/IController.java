package controller;

/**
 * Interface for the controller.
 */
public interface IController {

  /**
   * Starts the program.
   */
  void run();

}
